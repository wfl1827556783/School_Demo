﻿#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX_FUNDS 10 // 最大基金数量
#define FUND_FILE_PATH "D:\\Code\\C\\School_Demo\\SourceFile\\Fund.txt" // 文件路径

typedef struct {
	int  TID;//交易ID 
	char Trade_time[30];//交易时间
	char type;//交易类型
	int  UID;//交易用户ID
	int  FID;//基金ID
} JOURNAL;
typedef struct {
	float price;//基金价格
	int All_number;//基金总数量
	int buy_people;//购买基金人数
	int buy_number;//购买基金数量
	int FID;//基金ID 
	char Name[30];//基金名称
	JOURNAL Journal;//嵌套基金交易数据
} FUND;
typedef struct {
	int  UID;//UID
	char name[20];//账号
	char pwd[20];//密码
	char fonds[20];//购买基金信息
	int balance;//余额
	FUND fund;//嵌套基金信息数据
	JOURNAL Journal;//嵌套基金交易数据
}USER;
struct Account {
	int uid;
	char username[20];
	char password[20];
};
struct Account current_account;

FUND fund[11];

extern char choose;

void InsertFund(const char* filename);
void DisplayFund(const char* filename);
void UpdateFund(const char* filename);
int FID_Count();
void Findtype(); // 查询分类函数
void SortByFID(); // 以FID排序函数
void SortByRate(); // 以涨幅排序函数
void SortByPrice(); // 以价格排序函数
void RandomRate(); // 随机涨幅函数
void Swap(FUND* a, FUND* b);
void Sortprice(FUND f[], int N);
void LoadFundData(const char* filename, FUND fund[], int* fundCount);

void InsertFund(const char* filename) {
	FILE* fp = fopen(filename, "a"); // 以追加模式打开文件
	if (fp == NULL) {
		printf("无法打开文件\n");
		return;
	}

	FUND fund;
	printf("请依次输入基金名称、价格、基金总数量、购买人数、购买总数量：\n");
	scanf("%s %f %d %d %d", fund.Name, &fund.price, &fund.All_number, &fund.buy_people, &fund.buy_number);

	fund.FID = FID_Count(); // 生成唯一的基金ID

	// 写入基金信息到文件中
	fprintf(fp, "%d %.2f %d %d %d %s\n", fund.FID, fund.price, fund.All_number, fund.buy_people, fund.buy_number, fund.Name);
	printf("添加基金信息成功、详细信息如下:\n");
	printf("FID:%d 基金名：%s 价格:%.2f 总数:%d 购买人数：%d 已购买数量：%d \n", fund.FID, fund.Name, fund.price, fund.All_number, fund.buy_people, fund.buy_number);
	printf("==============================================================================================\n");
	fclose(fp);
}
void DisplayFund(const char* filename) {
	FILE* fp = fopen(filename, "r");
	if (fp == NULL) {
		printf("无法打开文件\n");
		return;
	}

	FUND fund;

	printf("读取的基金信息如下：\n");
	while (fscanf(fp, "%d %f %d %d %d %[^\n]", &fund.FID, &fund.price, &fund.All_number, &fund.buy_people, &fund.buy_number, fund.Name) != EOF) {
		printf("==============================================================================================\n");
		printf("\n基金ID: %d ", fund.FID);
		printf("基金名称: %s ", fund.Name);
		printf("价格: %.2f ", fund.price);
		printf("总数量: %d ", fund.All_number);
		printf("购买人数: %d ", fund.buy_people);
		printf("购买数量: %d \n\n", fund.buy_number);
	}
	printf("==============================================================================================\n");

	fclose(fp);
}
int FID_Count() {
	FILE* fp;
	int fid = 0;
	char line[100];

	fp = fopen("D:\\Code\\C\\School_Demo\\SourceFile\\Foud.txt", "r");
	if (fp == NULL) {
		printf("无法打开文件。\n");
		return -1; // 返回-1表示出错
	}

	// 逐行读取文件并计算 UID 数量
	while (fgets(line, sizeof(line), fp) != NULL) {
		int currentFID;
		sscanf(line, "%d", &currentFID);
		if (currentFID > fid) {
			fid = currentFID;
		}
	}

	fclose(fp);

	return fid + 1;
}
void UpdateFund(const char* filename) {
	FILE* fp = fopen(filename, "r+");
	if (fp == NULL) {
		printf("无法打开文件\n");
		return;
	}

	FILE* temp_fp = fopen("temp.txt", "w"); // 创建临时文件
	if (temp_fp == NULL) {
		printf("无法创建临时文件\n");
		fclose(fp);
		return;
	}

	int targetFID;
	printf("请输入要修改的基金ID: ");
	scanf("%d", &targetFID);

	FUND fund;
	int found = 0;

	while (fscanf(fp, "%d %f %d %d %d %[^\n]", &fund.FID, &fund.price, &fund.All_number, &fund.buy_people, &fund.buy_number, fund.Name) != EOF) {
		if (fund.FID == targetFID) {
			found = 1;
			break;
		}
		// 将非目标基金写入临时文件
		fprintf(temp_fp, "%d %.2f %d %d %d %s\n", fund.FID, fund.price, fund.All_number, fund.buy_people, fund.buy_number, fund.Name);
	}

	if (!found) {
		printf("未找到对应基金ID的记录\n");
		fclose(fp);
		fclose(temp_fp);
		remove("temp.txt"); // 删除临时文件
		return;
	}

	printf("找到基金信息如下：\n");
	printf("==============================================================================================\n");
	printf("\n基金ID: %d ", fund.FID);
	printf("基金名称: %s ", fund.Name);
	printf("价格: %.2f ", fund.price);
	printf("总数量: %d ", fund.All_number);
	printf("购买人数: %d ", fund.buy_people);
	printf("购买数量: %d \n\n", fund.buy_number);
	printf("==============================================================================================\n");

	printf("请选择要修改的内容:\n");
	printf("1.价格\n2.总数量\n3.基金名称\n");
	int option;
	scanf("%d", &option);
	fflush(stdin); // 清除输入缓冲区

	switch (option) {
	case 1:
		printf("请输入新的价格: ");
		scanf("%f", &fund.price);
		break;
	case 2:
		printf("请输入新的总数量: ");
		scanf("%d", &fund.All_number);
		break;
	case 3:
		printf("请输入新的基金名称: ");
		scanf("%s", fund.Name);
		break;
	default:
		printf("无效选项\n");
		fclose(fp);
		fclose(temp_fp);
		remove("temp.txt"); // 删除临时文件
		return;
	}

	// 写入更新后的数据到临时文件
	fprintf(temp_fp, "%d %.2f %d %d %d %s\n", fund.FID, fund.price, fund.All_number, fund.buy_people, fund.buy_number, fund.Name);

	// 复制剩余数据到临时文件
	while (fscanf(fp, "%d %f %d %d %d %[^\n]", &fund.FID, &fund.price, &fund.All_number, &fund.buy_people, &fund.buy_number, fund.Name) != EOF) {
		fprintf(temp_fp, "%d %.2f %d %d %d %s\n", fund.FID, fund.price, fund.All_number, fund.buy_people, fund.buy_number, fund.Name);
	}

	fclose(fp);
	fclose(temp_fp);

	remove(filename); // 删除原始文件
	rename("temp.txt", filename); // 将临时文件重命名为原始文件名称

	printf("基金信息修改成功\n");
}
void Findtype() {
	printf("请选择要查询的方式：\n");
	printf("1.单体查询  2.集体分类查询\n");
	scanf("%d", &choose);
	switch (choose) {
	case 1:
		printf("正在执行单体查询:\n");
		printf("请输入要查询的基金FId:\n");
		scanf("%d", &choose);
		//写一个基金结构体ID输出整个基金信息

		break;
	case 2:
		printf("请选择输出的排序方式：\n");
		printf("1.FID排序\n2.Price排序\n3.Rate排序\n");
		scanf("%d", &choose);
		switch (choose) {
		case 1:
			SortByFID();
			break;
		case 2:
			SortByPrice();
			break;
		case 3:
			SortByRate();
			break;
		default:
			printf("输出错误！\n");

			break;
		}
	default:
		break;
	}
}
void SortByFID() {
	DisplayFund(FUND_FILE_PATH);
}
void SortByPrice() {
	int fundCount = 0;
	LoadFundData(FUND_FILE_PATH, fund, &fundCount);
	Sortprice(fund, fundCount); // 使用加载的基金数量进行排序
	printf("==========基金价格排序后的数据=========\n");
	for (int i = 0; i < fundCount; ++i) {
		printf("名称：%s	ID:%d 价格%.2f 总数量:%d 购买人数：%d\n", fund[i].Name, fund[i].FID, fund[i].price, fund[i].All_number, fund[i].buy_people);
	}
}
// 选择排序
void Sortprice(FUND f[], int N) {
	int i, j, min_idx;
	for (i = 0; i < N - 1; i++) {
		min_idx = i;
		for (j = i + 1; j < N; j++) {
			if (f[j].price < f[min_idx].price) {
				min_idx = j;
			}
		}
		// Swap the found minimum element with the first element
		Swap(&f[min_idx], &f[i]);
	}
}
void Swap(FUND *a, FUND *b) {
	FUND temp = *a;
	*a = *b;
	*b = temp;
}
void LoadFundData(const char* filename, FUND fund[], int* fundCount) {
	FILE* fp = fopen(filename, "r");
	if (fp == NULL) {
		printf("无法打开文件\n");
		return;
	}

	*fundCount = 0; // 初始化基金数量为0

	// 逐行读取文件并将数据写入到数组中
	while (fscanf(fp, "%d %f %d %d %d %[^\n]", &fund[*fundCount].FID, &fund[*fundCount].price, &fund[*fundCount].All_number, &fund[*fundCount].buy_people, &fund[*fundCount].buy_number, fund[*fundCount].Name) != EOF) {
		(*fundCount)++; // 每读取一行数据，基金数量加1
	}

	fclose(fp);
}




void SortByRate() {
	
}
